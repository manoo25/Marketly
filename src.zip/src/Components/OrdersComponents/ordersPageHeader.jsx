

function OrdersPageHeader() {
    return (
        <>
            <header className="d-flex justify-content-between w-100 px-1 pt-3">
                <h3>الطلبات</h3>
            </header>
        </>
    );
}

export default OrdersPageHeader;
