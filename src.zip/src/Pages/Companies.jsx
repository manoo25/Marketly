import CompaniesPageHeader from "../Components/CompaniesComponents/CompaniesPageHeader";
import CompaniesTbl from "../Components/CompaniesComponents/CompaniesTbl";





function Companies() {
   
    
    return ( <>
 <CompaniesPageHeader/>
 <CompaniesTbl/>

    </> );
}

export default Companies;