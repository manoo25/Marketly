function Charts() {
    return ( <>
    <p>Charts Page</p>
  
    </> );
}

export default Charts;