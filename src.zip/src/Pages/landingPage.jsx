function Landing() {
  return (
    <>
      <p>Landing Page</p>
    </>
  );
}

export default Landing;
