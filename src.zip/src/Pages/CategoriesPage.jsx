function Categories() {
    return ( 
        <>
        <p>Categories Page</p>
        </>
     );
}

export default Categories;