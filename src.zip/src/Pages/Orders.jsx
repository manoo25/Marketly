import OrdersPageHeader from "../Components/OrdersComponents/ordersPageHeader";
import OrdersTbl from "../Components/OrdersComponents/ordersTbl";



function Orders() {
    return (
        <>
            <OrdersPageHeader />
            <OrdersTbl />
        </>

    );
}

export default Orders;